$('.btn-enviar').click( function(){
	//$('.form-envio').submit(function(event) {
	  // Event.preventDefault();
		var email =  $('#email').val();
		var assunto =  $('#assunto').val();
		var mensagem =  $('#mensagem').val();
	
		$.ajax({
		url: "php/envia-contato.php",
		data: FormData,
        cache: false,
        timeout: 70000,
		type: "POST",
		data: "email=email&assunto=assunto&mensagem=mensagem",
		dataType: "html",
		
		
		}).done(function(resposta) {
		//	alert("Email enviado com Sucesso!");
			console.log(resposta);

		}).fail(function(jqXHR, textStatus ) {
			console.log("Request failed: " + textStatus);

		}).always(function() {
			console.log("completou");
		});
	//});
});
