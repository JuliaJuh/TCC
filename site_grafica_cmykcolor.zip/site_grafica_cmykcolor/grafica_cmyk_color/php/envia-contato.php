<?php

	require 'PHPMailer/src/Exception.php';
	require 'PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/src/SMTP.php';
	
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
	

	
    		$email = $_POST["email"];
    		$assunto = $_POST["assunto"];
    		$mensagem = $_POST["mensagem"];
    	
    		$mail = new PHPMailer();
    		$mail->isSMTP();
    		$mail->Host = 'smtp.gmail.com';
    		$mail->Port = 587;
    		$mail->SMTPSecure = 'tls';
    		$mail->SMTPAuth = true;
    		$mail->Username = "contatositecmykcolor@gmail.com";
    		$mail->Password = "graficacmykcolor01";
    	
    		$mail->setFrom("conta-teste@gmail.com", "Contato");
    		$mail->addAddress("leticia.marinho532@gmail.com");
    		$mail->Subject = $assunto." *Enviado Pelo Site*";
    		$mail->msgHTML("<html> email:{$email} </br> Mensagem:{$mensagem} </html>");
    		$mail->AltBody = "de: email:{$email} \n mensagem: {$mensagem}";
    	
    		if($mail->send()){
    		    
    		    echo "<script type='text/javascript'>alert('Mensagem Enviada com Sucesso!');
window.location='../index.php';
</script>";
                
                
    		}
    		else{
    		    
    		    header("location:../index.php");
    		    echo '<script language="javascript">';
                echo 'alert("Opa! Mensagem não enviada :( ")';
                echo '</script>';
                
    		}
		
			
    
?>