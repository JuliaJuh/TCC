<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<link rel="Stylesheet" type="text/css" href="bootstrap.3.3.7-dist/css/bootstrap.min.css"/>
		<link rel="Stylesheet" type="text/css" href="css/estilo.css" />
		<link rel="Stylesheet" type="text/css" href="css/estilo_2.css" />
		<link rel="stylesheet" href="font-awesome/font-awesome.min.css">
		<!--<link rel="stylesheet" href="https://file.myfontastic.com/5snkrxHHMrEY5ybaZhVHUH/icons.css">-->
		<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
	 <link rel="stylesheet" href="css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		
	</head>
	<section id="home">	
			<body data-spy="scroll">
				<header class="header">
				 <nav class="navbar navbar-default navbar-fixed-top active">
			<div class="container">
			  <div class="navbar-header"><a href="index.html" class="navbar-brand"><img src="img/logo.png"></a>
				<div class="navbar-buttons">
				  <button type="button" data-toggle="collapse" data-target=".navbar-collapse" class="navbar-toggle navbar-btn">Menu<i class="fa fa-align-justify"></i></button>
				</div>
			  </div>
			  <div id="navigation" class="navbar-collapse navbar-right collapse" aria-expanded="true" style="">
				<ul class="nav navbar-nav">
				  <li class=""><a href="#home" class="link-scroll">Principal</a></li>
				  <li class="active"><a href="#sobre" class="link-scroll">Sobre</a></li>
				  <li class=""><a href="#catalogo" class="link-scroll">Catálogo</a></li>
				  <li class=""><a href="#precos" class="link-scroll">Preços</a></li>
				  <li class=""><a href="#contato" class="link-scroll">Contato</a></li>
				</ul>
			  </div>
			</div>
		  </nav>
				</header>
			
	</section>
		
		<main>
		<section class="sobre" id="sobre">
		   <!-- <h1 style="text-align:center; color:#8d8d8d;padding-bottom:70px; flex-flow: row wrap;">Sobre</h1>-->
			<!-- No media query img esta com problemas -->
		<!--	<img class="img-responsive center-block" src="img/imagem_sobre_juliana.png" alt="Generic placeholder image" width="210" height="210">
			<p>A Cmyk Color surgiu da mente da empresária Juliana, que resolveu montar uma empresa focada no cliente, tendo como principais produtos para o seu negócio ou para eventos, entre outras ocasiões. Sempre visando a qualidade do produto final, com entrega rapida e preços bem camarada.
			</p>-->
			<div class="col-lg-6 ">
			<h3 align="center" style="    text-align: center;
    color: #FFC125;
    padding-bottom: 70px;
    font-family: inherit;
    font-size: 3em;" class="titulo">Sobre Nós</h3>
			
			<img class="img-responsive center-block" src="img/imagem_sobre_juliana.png" alt="Generic placeholder image" width="210" height="210">
			<h5 align="center" style="color: #FFC125;">DESIGNER GRÁFICO E EMPRESÁRIA</h5>
			<div align="center">
			    <a href="https://www.facebook.com/cmykcoloroficial/"><i class="fa fa-facebook-square" style="font-size:28px color:#ffffff;"></i></a>
			    <!--<a href="#"><i class="fa fa-instagram" style="font-size:28px color:#ffffff;"></i></a>-->
			    
			</BR> </BR>
			<h4 align="center" style="color:#ffffff">Cmyk Color</h4>
			<p style="color:#ffffff">Surgiu da mente da empresária Juliana, que resolveu montar uma empresa focada no cliente, tendo como principais produtos para o seu negócio ou para eventos, entre outras ocasiões. Sempre visando a qualidade do produto final, com entrega rapida e preços bem camarada.</p>
		</div>
			

         
   </section>
		</section>
		
		<section id="catalogo">
				<section id="portfolio" class="portfolio">
				    <h1 class="titulo" style="text-align:center; color:#FFC125;padding-bottom:70px;font-family: inherit;
    font-size:3em;">Catálogo</h1>
			  <div class="container-fluid">
				<div class="row">
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item1"><img src="img/cartao-visita-4.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Cartões de Visita</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item2"><img src="img/folder1.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Panfletos</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item3"><img src="img/adesivo1.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Adesivos</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item4"><img src="img/banner2.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Banner</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item5"><img src="img/lona-2.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Lona</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item6"><img src="img/ilustracao1.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Ilustrações</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  <!-- Item-->
				   <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item7"><img src="img/capa-celular1.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Capas de Celular</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				   <!-- Item-->
				  <div class="item col-md-3 col-sm-6"><a href="#" data-toggle="modal" data-target="#portfolio-item8"><img src="img/camisa1.jpg" alt="item" class="img-responsive">
					  <div class="overlay">
						<div class="content">
						  <h2>Camisas</h2>
						  <p>Clique e veja mais modelos!</p>
						</div>
					  </div></a></div>
				  <!-- End Item-->
				  
				</div>
			  </div>
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			  <div id="portfolio-item1" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Cartoes de Visita</h2>
						  <p class="lead"></p>
							</div>
							
						  </div>
						  <div class="screen"><img src="img/cartao-visita1.jpg" alt="..." class="img-responsive"></div>
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/cartao-visita2.jpeg" alt="..." class="img-responsive"></div></br>
						<div class="screen"><img src="img/cartao-visita3.jpeg" alt="..." class="img-responsive"></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Modal-->
			  <div id="portfolio-item2" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Panfletos</h2>
						  <p class="lead"></p>
							</div>
							
						  </div>
						  <div class="screen"><img src="img/folder3.jpeg" alt="..." class="img-responsive"></div>
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/folder2.jpg" alt="..." class="img-responsive"></div></br>
						<div class="screen"><img src="img/folder1.jpg" alt="..." class="img-responsive"></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			  <div id="portfolio-item3" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Adesivos</h2>
						  <p class="lead"></p>
							</div>
							
						  </div>
						  <div class="screen"><img src="img/adesivo1.jpg" alt="..." class="img-responsive"></div>
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/adesivo2.jpg" alt="..." class="img-responsive"></div></br>
					
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			  <div id="portfolio-item4" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Banner</h2>
						  <p class="lead"></p>
							</div>
							
						  </div>
						  <div class="screen"><img src="img/banner1.jpg" alt="..." class="img-responsive"></div>
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/banner2.jpg" alt="..." class="img-responsive"></div></br>
						<!--<div class="screen"><img src="img/banner3.jpeg" alt="..." class="img-responsive"></div>-->
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			   <div id="portfolio-item5" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Lona</h2>
						  <p class="lead"></p>
							</div>
							
						  </div>
						 
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/lona-2.jpg" alt="..." class="img-responsive"></div></br>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			  <div id="portfolio-item6" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Ilustações</h2>
							<p class="lead"></p>
						  
							</div>
							
						  </div>
						 
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/ilustracao2.jpg" alt="..." class="img-responsive"></div></br>
						
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			  <div id="portfolio-item7" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Capas de Celular</h2>
							<p class="lead"></p>
						  
							</div>
							
						  </div>
						  <div class="screen"><img src="img/capa-celular1.jpg" alt="..." class="img-responsive"></div>
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/capa-celular2.jpg" alt="..." class="img-responsive"></div></br>
						
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  <!-- Demo Portfolio Modal - Duplicate for more items, replace id with a new one-->
			  <div id="portfolio-item8" tabindex="-1" role="dialog" class="modal fade">
				<div role="document" class="modal-dialog">
				  <div class="modal-content">
					<div data-dismiss="modal" aria-label="Close" class="close-btn"><i class="icon-close"><span class="glyphicon glyphicon-remove"></i></div>
					<div class="container-fluid">
					  <div class="row">
						<div class="mockup col-md-6">
						  <div class="device-mockup macbook_2015 portrait gold">
							<div class="device">
							 <h2>Camisas</h2>
							<p class="lead"</p>
						  
							</div>
							
						  </div>
						 
						</div>
						<div class="text col-md-6">
						  <div class="screen"><img src="img/camisa1.jpg" alt="..." class="img-responsive"></div></br>
						
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  <!-- End Modal-->
			  
    </section>
		
		
	</section>
		
	<section id="precos">
	<h1 class="titulo" style="text-align:center;color:#FFC125;padding-bottom:70px;font-family: inherit;
    font-size:3em;">Preços</h1>
		<span style="padding-top:5%;"></span>
		 <div align="center"  class='wrapper' >
			  <div class='package cartao'>
				<div class='name'><b>Cartões de Visita</b></div>
				
				<div class='trial'>COUCHÊ 250 G/M²</div>
				<ul class="ul_package">
				  <li>

					9X5 CM | 4X0 <p style="color:#FFC125">R$60,00</p>
				  </li>
				  <li>
					9X5 CM | 4X1 <p style="color:#FFC125">R$60,00</p>
				  </li>
				  <li>
					9X5 CM | 4X4 <p style="color:#FFC125">R$70,00</p>
				  </li>
				</ul>
				<div class='trial'>LAM. FOSCA C/ VERNIZ LOCAL.</div>
				<ul class="ul_package">
				  <li>
					9X5 CM | 4X4 <p style="color:#FFC125">R$160,00</p>
				  </li>
				 </ul>
			  </div>
			  <div class='package panfletos'>
				<div class='name'>Panfletos</div>
				<div class='trial'>COUCHÊ 115 G/M²</div>
				<ul class="ul_package">
				  <li>
					
					10X15 CM | 4X0 – 3000 UNID <p style="color:#FFC125">R$130,00</p>
				  </li>
				  <li>

					10X15 CM | 4X4 – 3000 UNID <p style="color:#FFC125">R$150,00</p>
				  </li>
				  <li>

					15X21 CM | 4X0 – 3000 UNID <p style="color:#FFC125">R$260</p>
				  </li>
				  <li>
				   15X21 CM | 4X4 – 3000 UNID <p style="color:#FFC125">R$390</p>
				  </li>
				  <li>
					21X30 CM | 4X0 – 3000 UNID <p style="color:#FFC125">R$520</p>
				  </li>
				  <li>
					21X30 CM | 4X4 – 3000 UNID <p style="color:#FFC125">R$790</p>
				  </li>
				</ul>
			  </div>
			  <div class='package banner'>
				<div class='name'>Banner</div>
				<ul class="ul_package">
				  <li>

					40X60CM <p style="color:#FFC125">R$30,00</p>
				  </li>
				  <li>

					50X70CM <p style="color:#FFC125">R$40,00</p>
				  </li>
				  <li>

				   60X80CM <p style="color:#FFC125">R$50,00</p>
				  </li>
				  <li>

				   70X100CM <p style="color:#FFC125">R$60,00</p>
				  </li>
				  <li>

				   80X120CM <p style="color:#FFC125">R$80,00</p>
				  </li>
				</ul>
				</div>
			 <div class='package adesivo'>
				<div class='name'>Adesivos</div>
				<div class='trial'>COUCHÊ 115 G/M²</div>
				<ul class="ul_package">
				  <li>
				   FOLHA <p style="color:#FFC125">R$45</p>
				  </li>
				</ul>
			  </div>
			  <div class='package camisa'>
				<div class='name'>Camisas</div>

				<ul class="ul_package">
				  <li>
					CAMISA BRANCA SUBLIMADA – A3 <p style="color:#FFC125">R$35,00</p>
				  </li>
				</ul>
			  </div>
			  <div class='package ilustracao'>
				<div class='name'>Ilustrações</div>
				<ul class="ul_package">
				  <li>
					A partir de <p style="color:#FFC125">R$20,00</p>
				  </li>
				</ul>
			  </div>
			  <div class='package celular'>
				<div class='name'>Capas de Celular</div>
				<div class='trial'>Unidade – R$50,00 | 5 Unidades R$200,00</div>
				<div class='trial'>APPLE</div>
				
				<ul class="ul_package">

				  <li>
					
				   Iphone 4, 4s | Iphone 5, 5s, se | Iphone 6s
				  </li>
				  <li>

					Iphone 6s plus | Iphone 7 | Iphone 7 plus
				  </li>
				</ul>
				<div class='trial'>ASUS</div>
				
				<ul class="ul_package">

				  <li>
					
				   Zenfone 3 Tela 5,2 | Zenfone 3 Zoom
				  </li>
				</ul>
				
				<ul class="ul_package">

				  <li>
					
				   Fazemos em outros modelos de capinha também!</br>
				   Entre em Contato para saber mais!
				  </li>
				</ul>
				
				</div>
				</div>
			</div>
			<span style="padding-bottom:5%;"></span>
		</section>
		
			
		
		</main>
		
		<div class="footer" id="contato">
		    <div class="marketing resumo col-lg-2 links">
					  <!-- Three columns of text below the carousel -->
							<div>
							
								<h3 style="color: #FFC125;">Gráfica Cmyk Color</h3>
								<ul class="list-unstyled">
    								<li><a href="#home" class="link-scroll">Principal</a></li>
    								<li><a href="#sobre" class="link-scroll">Sobre</a></li>
    							    <li><a href="#catalogo" class="link-scroll">Catálogo</a></li>
    								<li><a href="#precos" class="link-scroll">Preços</a></li>
    								<li><a href="#contato" class="link-scroll">Contato</a></li>
								</ul>
							</div>
				</div>
				<div class="marketing resumo col-lg-2 links">
					  <!-- Three columns of text below the carousel -->
							<div>
							
								<h3 style="color: #FFC125;">Redes Sociais</h3>
								<p class="resumo_texto" style="">
								Entre contato comigo através das redes socias!</br>
								
									<a href="tel:+021987415199" style="font-size:20px; display:inline-block; color:#34af23"><b></b>(21) 98741-5199 </b><i class="fa fa-whatsapp" style="font-size:25px; color:#34af23"></i></a></br>
									<a  href="https://www.facebook.com/cmykcoloroficial/"><i class="fa fa-facebook-official" style="font-size:24px"></i></a>
									<a href="mailto:webmaster@example.com"><i class="fa fa-envelope" style="font-size:24px"></i></a>
								</p>
								
							</div>
				</div>
			
				<div class="contato col-lg-2 links">
					<h3>Contato</h3>
					  <form action="php/envia-contato.php" method="POST">
						  <div class="form-group">
							<label for="exampleFormControlInput1">Seu E-mail</label>
							<input type="email" class="form-control" id="email" placeholder="exemplo@exemplo.com" name="email">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1">Escolha Um Assunto</label>
							<select class="form-control" id="assunto" name="assunto">
							  <option selected disabled>Selecione uma Opção</option>
							  <option>Orçamento</option>
							  <option>Reclamação</option>
							  <option>Sugestão</option>
							  <option>Elogio</option>
							  <option>Pedido</option>
							  <option>Informações</option>
							  <option>Outro</option>
							</select>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlTextarea1" name="mensagm">Mensagem</label>
							<textarea class="form-control" id="mensagem" name="mensagem" rows="3"></textarea>
						  </div>
						  <button type="submit" class="btn btn-primary btn-enviar" name="enviar">Enviar</button>
						</form>
				</div>
			</footer>
	</body>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="bootstrap.3.3.7-dist/js/bootstrap.min.js"></script>
		<script src="script\script_menu.js"></script>
		<!--<script>$(document).ready(function(){alert("Oque falta para seu termino: \nBanner principal responsivo, fontes de acordo com o gosto da cliente, texto dentro do catálogo e ajeitar algumas funções jQuery");});</script>-->
		<!--<script src="script\conexao-index-envia-contato.js"></script>-->
		<!--<script src="script/jquery.validate.min.js"></script>-->
		<!--<script src="script/script_menu.js"></script>-->
</html>

<!-- http://demo.bootstrapious.com/foliou/  http://newagenciadigital.com.br/ -->
<!-- https://www.w3schools.com/bootstrap/bootstrap_scrollspy.asp https://picjumbo.com/-->